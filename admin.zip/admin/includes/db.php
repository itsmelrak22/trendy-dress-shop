<?php

$con = mysqli_connect("localhost","root","admin","ecomm_store");
// $con = mysqli_connect("localhost","u916113351_root","Trendydresshopsystem@2024","u916113351_ecomm_store");

?>
